# YDTT Factory — Cloudflare root-assets configuration patch

This patch updates the existing repository so Cloudflare serves the root `index.html`
while keeping `worker.mjs` as the API relay.

## Files in this patch

- `wrangler.toml` — points Cloudflare Static Assets at the repository root.
- `.assetsignore` — allows only the root `index.html` to be uploaded as a public static asset.

## Apply

Replace the repository's existing `wrangler.toml` with this version and add `.assetsignore`
at the repository root. Keep the existing `index.html` and `worker.mjs` unchanged.

The asset allowlist is intentional: do not remove `.assetsignore` or broaden it to `*`
without the `!index.html` exception, otherwise private project/source/config files could
be exposed as static assets.

## Runtime

- `/` is served by Cloudflare Static Assets from `index.html`.
- `/health`, `/v1/models`, and `/v1/chat/completions` are handled by `worker.mjs`.
- The Factory should use the same Cloudflare Worker origin as its Relay URL. This keeps
  browser requests same-origin and avoids requiring permissive CORS.
- Keep existing Worker secrets `APIVN_API_KEY` and `RELAY_ACCESS_TOKEN`; do not put
  either secret in this repository.

This is a configuration patch, not a deployment. Deploy the Worker after committing
these files, then verify `/`, `/health`, and model discovery before relying on it.
